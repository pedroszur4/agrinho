let player;
let waterDrops = [];
let trees = [];
let obstacles = [];
let score = 0;
let water = 0;
let totalTrees = 5;
let gameOver = false;
let gameResult = ""; // "win" ou "lose"

function setup() {
  createCanvas(800, 600);
  player = new Player();
  for (let i = 0; i < 5; i++) {
    waterDrops.push(new WaterDrop());
  }
  for (let i = 0; i < 3; i++) {
    obstacles.push(new Obstacle());
  }
}

function draw() {
  background("green");

  if (gameOver) {
    fill(0);
    textSize(32);
    textAlign(CENTER, CENTER);
    if (gameResult === "win") {
      text("Parabéns! Você ajudou o meio ambiente! 🌍", width / 2, height / 2);
    } else if (gameResult === "lose") {
      text("Poluição venceu! Você perdeu a batalha.", width / 2, height / 2);
    }
    return;
  }

  // Título
  fill(0);
  textSize(24);
  text("Fazenda Sustentável 🌾 - Use setas e espaço para plantar", width / 2, 30);

  // Atualiza jogador
  player.update();
  player.show();

  // Gotas de água
  for (let i = waterDrops.length - 1; i >= 0; i--) {
    waterDrops[i].show();
    if (player.collect(waterDrops[i])) {
      waterDrops.splice(i, 1);
      water++;
    }
  }

  // Árvores
  for (let tree of trees) {
    tree.show();
  }

  // Obstáculos
  for (let obs of obstacles) {
    obs.show();
    if (player.hits(obs)) {
      gameOver = true;
      gameResult = "lose";
    }
  }

  // Interface
  fill(0);
  textSize(18);
  text("💧 Água: " + water, 70, 60);
  text("🌳 Árvores plantadas: " + score, 200, 60);

  // Vitória
  if (score >= totalTrees) {
    gameOver = true;
    gameResult = "win";
  }
}

function keyPressed() {
  if (key === ' ' && water > 0 && score < totalTrees && !gameOver) {
    trees.push(new Tree(player.x, player.y));
    water--;
    score++;
  }
}

// === CLASSES ===

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 60;
    this.size = 48;
    this.emoji = "👨‍🌾";
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) this.x -= 5;
    if (keyIsDown(RIGHT_ARROW)) this.x += 5;
    if (keyIsDown(UP_ARROW)) this.y -= 5;
    if (keyIsDown(DOWN_ARROW)) this.y += 5;

    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  show() {
    textSize(this.size);
    textAlign(CENTER, CENTER);
    text(this.emoji, this.x, this.y);
  }

  collect(drop) {
    let d = dist(this.x, this.y, drop.x, drop.y);
    return d < 40;
  }

  hits(obs) {
    let d = dist(this.x, this.y, obs.x, obs.y);
    return d < 40;
  }
}

class WaterDrop {
  constructor() {
    this.x = random(50, width - 50);
    this.y = random(50, height - 150);
    this.size = 32;
    this.emoji = "💧";
  }

  show() {
    textSize(this.size);
    text(this.emoji, this.x, this.y);
  }
}

class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 32;
    this.emoji = "🌳";
  }

  show() {
    textSize(this.size);
    text(this.emoji, this.x, this.y - 20);
  }
}

class Obstacle {
  constructor() {
    this.x = random(100, width - 100);
    this.y = random(100, height - 100);
    this.size = 32;
    this.emoji = "☣️";
  }

  show() {
    textSize(this.size);
    text(this.emoji, this.x, this.y);
  }
}
